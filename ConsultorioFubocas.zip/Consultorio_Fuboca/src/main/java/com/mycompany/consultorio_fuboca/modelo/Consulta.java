/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.modelo;

/**
 *
 * @author aluno.den
 */
import java.time.LocalDate;
import java.time.LocalTime;

public class Consulta {
    private int idConsulta;
    private String nomePaciente;
    private String nomeMedico;
    private LocalDate data;
    private LocalTime hora;
    private String observacao;
    

    public Consulta() {
        
    }
    
    public Consulta(String nomePaciente, String nomeMedico,LocalDate data, LocalTime hora,String observacao ) {
       
        this.nomePaciente = nomePaciente;
        this.nomeMedico = nomeMedico;
        this.data = data;
        this.hora = hora;
        this.observacao = observacao;
    }

    public Consulta(int idConsulta,String nomePaciente, String nomeMedico , LocalDate data, LocalTime hora, String observacao) {
        this.idConsulta = idConsulta;
        this.nomePaciente = nomePaciente;
        this.nomeMedico = nomeMedico;
        this.data = data;
        this.hora = hora;
        this.observacao = observacao;
       
    }

    public int getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public String getnomePaciente() {
        return nomePaciente;
    }

    public void setnomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public String getnomeMedico() {
        return nomeMedico;
    }

    public void setIdMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }
    
}